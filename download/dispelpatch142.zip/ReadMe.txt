Je�eli automatyczne zainstalowanie uaktualnienia do gry Dispel PL jest niemo�liwe,
konieczna jest instalacja r�czna.

Zamie� pliki dispel.exe i store.db znajduj�ce si� w folderze z zainstalowan� gr�.

Do folderu g��wnego skopiuj plik  dispel.exe,
natomiast do pod-folderu \CharacterInGame, plik store.db.